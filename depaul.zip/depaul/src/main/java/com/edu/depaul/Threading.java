package com.edu.depaul;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Threading {

	public static void runThread(File[] files, int noOfThreads, int thread, int filePerThread, int remainingFiles) {

		List<File> inFiles = new ArrayList<>();
		for (int i = thread * filePerThread; i < (thread + 1) * filePerThread; i++) {
			inFiles.add(files[i]);
		}
		if (thread == noOfThreads - 1 && remainingFiles > 0) {
			for (int j = files.length - remainingFiles; j < files.length; j++) {
				inFiles.add(files[j]);
			}
		}
		for (File file : inFiles) {
			System.out.println("processing : " + file.getName() + " in thread " + Thread.currentThread().getName());
		}
	}

	public static void main(String[] args) {

		File folder = new File("src//main//resources//Dataset1");
		File[] listofFiles = folder.listFiles();

		int numberOfThreads = 2;
		Thread[] threads = new Thread[numberOfThreads];

		final int filesPerThread = listofFiles.length / numberOfThreads;
		final int remainingFiles = listofFiles.length % numberOfThreads;

		// Assigning files dynamically to each thread
		for (int i = 0; i < numberOfThreads; i++) {
			final int thread = i;
			threads[i] = new Thread() {
				@Override
				public void run() {
					runThread(listofFiles, numberOfThreads, thread, filesPerThread, remainingFiles);
				}
			};
		}
		for (Thread t1 : threads) {
			t1.start();
		}
		for (Thread t2 : threads) {
			try {
				t2.join();
			} catch (InterruptedException e) {

			}
		}

	}
}
