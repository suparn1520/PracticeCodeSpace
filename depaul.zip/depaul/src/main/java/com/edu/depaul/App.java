package com.edu.depaul;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Hello world!
 *
 */
public class App {

	public static void main(String[] args) throws Exception {

		Scanner sc = new Scanner(System.in);

		try {
			while (true) {
				System.out.println("\n\nChoose following Options to perform task : ");
				System.out.println("1. File Indexing");
				System.out.println("2. Perform Searching in a Specific dataset");
				System.out.println("3. Quit");

				int choice = sc.nextInt();
				sc.nextLine();

				switch (choice) {

				case 1:
//					System.out.println(
//							"You have choosen File Indexing. Following Files are present under these DataSets :\n\n");

					System.out.print("Enter No. of Threads to perform MultiThreading : ");
					int threads = sc.nextInt();

					IndexStore indexdocuments = new IndexStore();
					Map<String, File[]> dataSetDocuments = new HashMap<String, File[]>();
					dataSetDocuments = (indexdocuments.listAlldocumentsAnddataSets("src//main//resources", threads));

					for (Map.Entry<String, File[]> mapEntry : dataSetDocuments.entrySet()) {
						System.out.println(mapEntry.getKey().toString());
						for (File f : mapEntry.getValue()) {
							System.out.println(f.getAbsolutePath().toString());
						}
					}
					dataSetDocuments = null;
					break;

				case 2:
					System.out.println("You have chosen Search Operation");

//					for (Map.Entry<String, Set<String>> mapEntry : resultantMap.entrySet()) {
//						System.out.print(mapEntry.getKey().toString());
//						System.out.println(mapEntry.getValue());
//						System.out.println(mapEntry.getValue().size());
//					}

					System.out.print("Enter item to Search : ");
					String input = sc.nextLine();

					System.out.println("In which DataSet you want to search this input ? ");
					System.out.println("Enter like this : Dataset1 / Dataset2... Dataset5");
					String dataSetName = sc.nextLine().toString();

					ArrayList<String> validDataSets = new ArrayList<String>();

					String pathOfResources = "src//main//resources//";

					File folder = new File(pathOfResources);
					for (File f : folder.listFiles()) {
						validDataSets.add(f.getName().toString());
					}

					if (!validDataSets.contains(dataSetName)) {
						System.out.println("Dataset value Incorrect...");
						break;
					}

					RetrievDataEngine engine = new RetrievDataEngine();
					Map<String, Set<String>> resultantMap = new HashMap<String, Set<String>>();
					resultantMap = engine.generateDocWordPair(pathOfResources, dataSetName);

					FileRetrievalEngine fileEngine = new FileRetrievalEngine();

					if (input.contains(" OR ")) {
						System.out.println("OR method");
						fileEngine.alphaNumericStringWithOR(input, resultantMap);
					} else if (input.contains(" AND ")) {
						System.out.println("AND method");
						fileEngine.alphaNumericStringWithAND(input, resultantMap);
					} else {
//						System.out.println("Normal method");
						ThreadPoolFiles indexThreading = new ThreadPoolFiles();
						indexThreading.MultiThreadingSearching(resultantMap, 4, input);
//						fileEngine.alphaNumericString(input, resultantMap);
					}
					resultantMap = null;
					break;

				case 3:
					System.out.println("Exiting the program.");
					sc.close();
					System.exit(0);
				default:
					System.out.println("Invalid option. Please select a valid option.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
