package com.edu.depaul;

import java.io.File;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Class to Store documents present in all DataSets using MultiThreading
public class IndexStore {

	public Map<String, File[]> listAlldocumentsAnddataSets(String pathOfResources, int noOfThreads) {

		Instant startTime = Instant.now();

		File folder = new File(pathOfResources);
		File[] allDataSets = folder.listFiles();

		int n = allDataSets.length;
		int chunkSize = n / noOfThreads; // 4 = no. Of Threads... You can Specify Any no. of threads

		List<Thread> threads = new ArrayList<>();
		Map<String, File[]> mapOfDataSetdocuments = new HashMap<String, File[]>();

		for (int i = 0; i < noOfThreads; i++) {
			int temp = i;
			Thread t = new Thread(() -> {
				int start = temp * chunkSize;
				int end = (temp == noOfThreads - 1) ? n : (temp + 1) * chunkSize;

				for (int j = start; j < end; j++) {
					mapOfDataSetdocuments.put(allDataSets[j].getAbsolutePath().toString(), allDataSets[j].listFiles());
				}
			});
			threads.add(t);
			t.start();
		}

		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		Instant end = Instant.now();
		long time = Duration.between(startTime, end).toMillis();
		System.out.println("Time of execution : " + time + "ms");
		startTime = end = null;
		return (mapOfDataSetdocuments);
	}

}
